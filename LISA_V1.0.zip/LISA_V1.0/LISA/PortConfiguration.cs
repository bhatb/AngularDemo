﻿using System;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Net.NetworkInformation;

namespace LISA
{
    public partial class PortConfiguration : Form
    {
        private CONNECTION objCONNECTION;
        private static DataTable DTAnalyzer;
        private static DataTable DTMAXID;
        private static DataTable DTComportSettings;
        private StreamWriter sw;
        private static bool is_update = false;
        

        public PortConfiguration()
        {
            InitializeComponent();
        }

        private void Load_Analyzers()
        {
            try
            {
                objCONNECTION = new CONNECTION();
                DTAnalyzer = new DataTable();
                DTAnalyzer = objCONNECTION.GetDataTable("SELECT distinct mana_machinenameid id,mana_machinename analyzer_name FROM lb_mana_machinename WHERE mana_isactive = 'Y' ORDER BY mana_machinenameid ASC");
                
                if (DTAnalyzer.Rows.Count > 0)
                {
                    cmbAnalyserName.Items.Clear();
                    cmbAnalyserName.DataSource = DTAnalyzer;
                    cmbAnalyserName.DisplayMember = "analyzer_name";
                    cmbAnalyserName.ValueMember = "id";
                }

            }
            catch (Exception ex)
            {
                sw = File.AppendText(Application.StartupPath + "\\AnalyzerName.log");
                sw.WriteLine(DateTime.Now.ToString() + " : AnalyzerName : " + ex.Message);
                sw.Close();
            }
        }

        private string check_macaddress()
        {
            string text = string.Empty;
            NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface networkInterface in allNetworkInterfaces)
            {
                if (networkInterface.OperationalStatus == OperationalStatus.Up)
                {
                    text += networkInterface.GetPhysicalAddress().ToString();
                    break;
                }
            }
            return text;
        }

        private void ComportDetails_Load()
        {
            try
            {
                cmbAnalyserName.Focus();
                cmbAnalyserName.Items.Clear();
                string[] ports = SerialPort.GetPortNames();
                comboBox_comport.Items.Clear();
                foreach (string comport in ports)
                {
                    comboBox_comport.Items.Add(comport);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void radioButtonNetwork_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonNetwork.Checked == true)
            {
                groupBoxNetwork.BackColor = Color.MintCream;
                groupBoxSerial.BackColor = Color.Thistle;
                groupBoxNetwork.Enabled = true;
                groupBoxSerial.Enabled = false;
                groupBox_filebased.Enabled = false;

            }
        }

        private void radioButtonSerial_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonSerial.Checked == true)
            {
                groupBoxNetwork.BackColor = Color.Thistle;
                groupBoxSerial.BackColor = Color.MintCream;
                groupBoxNetwork.Enabled = false;
                groupBoxSerial.Enabled = true;
                groupBox_filebased.Enabled = false;

            }
        }

        private void radioButton_filebased_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_filebased.Checked == true)
            {
                groupBoxNetwork.BackColor = Color.Thistle;
                groupBoxSerial.BackColor = Color.MintCream;
                groupBoxNetwork.Enabled = false;
                groupBoxSerial.Enabled = false;
                groupBox_filebased.Enabled = true;

            }
        }

        private void PortConfiguration_Load(object sender, EventArgs e)
        {
            ComportDetails_Load();
            Load_Analyzers();
            groupBoxNetwork.Enabled = false;
            groupBox_filebased.Enabled = false;
            LoadDbgridData();
        }

        private void LoadDbgridData()
        {
            objCONNECTION = new CONNECTION();

            DTComportSettings = new DataTable();
            string mac_address = check_macaddress();
            DTComportSettings = objCONNECTION.GetDataTable(" select (select mana_machinename from lb_mana_machinename where mana_machinenameid=cs_analyzerid)analyzer,cs_protocol protocol,cs_portnumber portnumber,cs_hostip hostip, cs_analyzerip analyzerip, cs_parity parity,cs_baudrate baudrate,cs_stopbits stopbits,cs_databits databits,cs_handshake handshake,cs_dtr_rts dtrrts,cs_isactive active,cs_analyzerid analyzerid,cs_mode modec,cs_filepath filepath from lb_cs_comportsetting lcc where cs_macaddress= '" + mac_address + "' order by cs_comportid desc");
            dataGridView_comportsettings.DataSource = DTComportSettings;
        }

        private void button_clear_Click(object sender, EventArgs e)
        {

            comboBox_comport.SelectedIndex = -1;
            comboBoxBaudRate.SelectedIndex = -1;
            comboBox_databits.SelectedIndex = -1;
            comboBox_stopbits.SelectedIndex = -1;
            comboBox_handshake.SelectedIndex = -1;
            comboBox_parity.SelectedIndex = -1;
            cmbAnalyserName.SelectedIndex = -1;

            textBox_hostip.Text = "";
            textBox_analyzerip.Text = "";
            textBox_portno.Text = "";
            textBox_FILEPATH.Text = "";



        }

        private void button_save_Click(object sender, EventArgs e)
        {

            string mac_address = check_macaddress();
            objCONNECTION = new CONNECTION();

         
            if (radioButtonSerial.Checked == true)
                DTMAXID = objCONNECTION.GetDataTable("select cs_analyzerid maxitem FROM lb_cs_comportsetting where cs_macaddress ='" + mac_address + "'" + " AND cs_portnumber ='" + comboBox_comport.Text.ToString().Trim() + "'");
            else if (radioButtonNetwork.Checked == true)
                DTMAXID = objCONNECTION.GetDataTable("select cs_analyzerid maxitem FROM lb_cs_comportsetting where cs_macaddress ='" + mac_address + "'" + " AND cs_portnumber ='" + textBox_portno.Text.ToString().Trim() + "'");
            else if (radioButton_filebased.Checked == true)
                DTMAXID = objCONNECTION.GetDataTable("select cs_analyzerid maxitem FROM lb_cs_comportsetting where cs_macaddress ='" + mac_address + "'" + " AND cs_filepath ='" + textBox_FILEPATH.Text.ToString().Trim() + "'");


            if (DTMAXID.Rows.Count > 0)
            {
                if (radioButton_filebased.Checked == true)
                    MessageBox.Show("FilePath is Already Exist !!!");
                else
                    MessageBox.Show("Port is Already Exist !!!");
                return;
            }

            string isactive = null;
            StringBuilder sb1 = new StringBuilder();

            if (checkBox_isactive.Checked == true)
            {
                isactive = "true";
            }
            else
            {
                isactive = "false";
            }

            if (radioButton_filebased.Checked == true)
            {
                try
                {

                    sb1.Append("insert into lb_cs_comportsetting(cs_analyzerid,cs_protocol,cs_macaddress,cs_filepath) values (");
                    sb1.Append( cmbAnalyserName.SelectedValue.ToString() + "," + "'FILEBASED','");
                    sb1.Append(mac_address +"','"+ textBox_FILEPATH.Text+ "')");
                    objCONNECTION.ExecuteNonQuery(sb1.ToString());

                }
                catch (Exception ex)
                {
                    sw = File.AppendText(Application.StartupPath + "\\insertportsetting.txt");
                    sw.WriteLine(DateTime.Now.ToString() + ":" + "-" + ex.Message);
                    sw.Close();
                    throw ex;
                }
                finally
                {
                    MessageBox.Show("SUCCESS", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            if (radioButtonSerial.Checked == true)
            {
                if (comboBox_comport.SelectedIndex == -1 || comboBoxBaudRate.SelectedIndex == -1 || comboBox_databits.SelectedIndex == -1 || comboBox_stopbits.SelectedIndex == -1 || comboBox_handshake.SelectedIndex == -1 || comboBox_parity.SelectedIndex == -1 || cmbAnalyserName.SelectedIndex == -1)
                {
                    MessageBox.Show("Please fill up the necessary fields!");
                    return;
                }

                string dtr_rts = null;

                if (checkBox_DTRRTS.Checked == true)
                {
                    dtr_rts = "1";
                }
                else
                {
                    dtr_rts = "0";
                }


                try
                {

                    sb1.Append("insert into lb_cs_comportsetting(cs_analyzerid,cs_protocol,cs_portnumber,cs_parity,cs_baudrate,cs_stopbits,cs_handshake,cs_dtr_rts,cs_databits,cs_macaddress) values (");
                    sb1.Append(cmbAnalyserName.SelectedValue.ToString() + "," + "'SERIAL','" + comboBox_comport.Text.ToString() + "','" + comboBox_parity.Text.ToString() + "','" + comboBoxBaudRate.Text.ToString());
                    sb1.Append("','" + comboBox_stopbits.Text.ToString() + "','" + comboBox_handshake.Text.ToString() + "','" + dtr_rts.ToString() + "','" + comboBox_databits.Text.ToString() +"','" + mac_address + "')");
                    objCONNECTION.ExecuteNonQuery(sb1.ToString());
                   
                }
                catch (Exception ex)
                {
                    sw = File.AppendText(Application.StartupPath + "\\insertportsetting.txt");
                    sw.WriteLine(DateTime.Now.ToString() + ":" + "-" + ex.Message);
                    sw.Close();
                    throw ex;
                }
                finally
                {
                    MessageBox.Show("SUCCESS", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


            }

            if (radioButtonNetwork.Checked == true)
            {
                if (textBox_hostip.Text == "" || textBox_analyzerip.Text == "" || textBox_portno.Text == "")
                {
                    MessageBox.Show("Please fill up the necessary fields!");
                    return;
                }

                try
                {
                    string mode = null;
                    if (radioButton_server.Checked == true)
                    {
                        mode = "SERVER";
                    }
                    else
                    {
                        mode = "CLIENT";
                    }
                    
                    sb1.Append("insert into lb_cs_comportsetting(cs_analyzerid,cs_protocol,cs_portnumber,cs_hostip,cs_analyzerip,cs_mode, cs_macaddress) values (");
                    sb1.Append(cmbAnalyserName.SelectedValue.ToString() + "," + "'NETWORK','" + textBox_portno.Text.ToString() + "','" + textBox_hostip.Text.ToString() + "','" + textBox_analyzerip.Text.ToString());
                    sb1.Append("','" + mode +"','"+mac_address+ "')");
                    objCONNECTION.ExecuteNonQuery(sb1.ToString());
                    
                }

                catch (Exception ex)
                {
                    sw = File.AppendText(Application.StartupPath + "\\insertportsetting.txt");
                    sw.WriteLine(DateTime.Now.ToString() + ":" + "-" + ex.Message);
                    sw.Close();
                    throw ex;
                }
                finally
                {
                    MessageBox.Show("SUCCESS", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            LoadDbgridData();

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do You Want to Delete the record", "Delete!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {

                    int rowIndex = dataGridView_comportsettings.CurrentCell.RowIndex;
                    if (rowIndex > -1)
                    {
                        DataGridViewRow row = dataGridView_comportsettings.Rows[rowIndex];
                        string analyzer_id = row.Cells["analyzerid"].Value.ToString();
                        StringBuilder sb1 = new StringBuilder();
                        sb1.Append("delete from lb_cs_comportsetting where cs_analyzerid =" + analyzer_id);
                        objCONNECTION = new CONNECTION();
                        objCONNECTION.ExecuteNonQuery(sb1.ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            LoadDbgridData();
        }

        private void dataGridView_comportsettings_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            /*string cellValue = dataGridView_comportsettings.Rows[e.RowIndex].Cells[1].Value.ToString();
            is_update = true;
            if (cellValue == "SERIAL")
            {

                groupBoxNetwork.Enabled = false;
                groupBox_filebased.Enabled = false;
                cmbAnalyserName.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[0].Value.ToString();
                comboBox_comport.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[2].Value.ToString();
                comboBox_parity.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[5].Value.ToString();
                comboBoxBaudRate.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[6].Value.ToString();
                comboBox_stopbits.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[7].Value.ToString();
                comboBox_databits.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[8].Value.ToString();
                comboBox_handshake.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[9].Value.ToString();

                if (dataGridView_comportsettings.Rows[e.RowIndex].Cells[10].Value.ToString() == "0")
                {
                    checkBox_DTRRTS.Checked = false;
                }
                else
                {
                    checkBox_DTRRTS.Checked = true;
                }

            }
            else if (cellValue == "NETWORK")
            {
                groupBoxNetwork.Enabled = false;
                groupBox_filebased.Enabled = false;
                textBox_hostip.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox_portno.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox_analyzerip.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[4].Value.ToString();
                if (dataGridView_comportsettings.Rows[e.RowIndex].Cells[4].Value.ToString() == "SERVER")
                {
                    radioButton_server.Checked = true;
                    radioButton_client.Checked = false;
                }
                else
                {
                    radioButton_server.Checked = false;
                    radioButton_client.Checked = true;
                }
            }
            else if (cellValue == "FILEBASED")
            {
                textBox_FILEPATH.Text = dataGridView_comportsettings.Rows[e.RowIndex].Cells[14].Value.ToString();
            }


            if (dataGridView_comportsettings.Rows[e.RowIndex].Cells[11].Value.ToString() == "Y")
            {
                checkBox_isactive.Checked = true;
            }
            else
            {
                checkBox_isactive.Checked = false;
            } */

        }
    }
}

