﻿
namespace LISA
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_header = new System.Windows.Forms.Panel();
            this.label_name = new System.Windows.Forms.Label();
            this.button_minimize = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.AnalyzerDetails = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lISASETUPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ANALYZERCONFIGURATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIconLISA = new System.Windows.Forms.NotifyIcon(this.components);
            this.button_reload = new System.Windows.Forms.Button();
            this.panel_header.SuspendLayout();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_header
            // 
            this.panel_header.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panel_header.BackColor = System.Drawing.Color.Turquoise;
            this.panel_header.Controls.Add(this.label_name);
            this.panel_header.Controls.Add(this.button_minimize);
            this.panel_header.Controls.Add(this.button_exit);
            this.panel_header.Location = new System.Drawing.Point(0, 0);
            this.panel_header.Name = "panel_header";
            this.panel_header.Size = new System.Drawing.Size(924, 32);
            this.panel_header.TabIndex = 0;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_name.ForeColor = System.Drawing.Color.Indigo;
            this.label_name.Location = new System.Drawing.Point(17, 4);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(44, 23);
            this.label_name.TabIndex = 4;
            this.label_name.Text = "LISA";
            // 
            // button_minimize
            // 
            this.button_minimize.BackColor = System.Drawing.Color.Transparent;
            this.button_minimize.BackgroundImage = global::LISA.Properties.Resources.minimize;
            this.button_minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_minimize.FlatAppearance.BorderSize = 0;
            this.button_minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button_minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button_minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_minimize.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_minimize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_minimize.Location = new System.Drawing.Point(854, 2);
            this.button_minimize.Name = "button_minimize";
            this.button_minimize.Size = new System.Drawing.Size(28, 25);
            this.button_minimize.TabIndex = 3;
            this.button_minimize.UseVisualStyleBackColor = false;
            this.button_minimize.Click += new System.EventHandler(this.button_minimize_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.Transparent;
            this.button_exit.BackgroundImage = global::LISA.Properties.Resources.close2;
            this.button_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button_exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_exit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_exit.Location = new System.Drawing.Point(888, 3);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(26, 26);
            this.button_exit.TabIndex = 2;
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // AnalyzerDetails
            // 
            this.AnalyzerDetails.AutoScroll = true;
            this.AnalyzerDetails.BackColor = System.Drawing.Color.GhostWhite;
            this.AnalyzerDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AnalyzerDetails.Location = new System.Drawing.Point(3, 63);
            this.AnalyzerDetails.Name = "AnalyzerDetails";
            this.AnalyzerDetails.Size = new System.Drawing.Size(920, 361);
            this.AnalyzerDetails.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_reload);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Location = new System.Drawing.Point(3, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(923, 26);
            this.panel1.TabIndex = 2;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lISASETUPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(923, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lISASETUPToolStripMenuItem
            // 
            this.lISASETUPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ANALYZERCONFIGURATIONToolStripMenuItem,
            this.portConfigurationToolStripMenuItem});
            this.lISASETUPToolStripMenuItem.Name = "lISASETUPToolStripMenuItem";
            this.lISASETUPToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.lISASETUPToolStripMenuItem.Text = "LISA SETUP";
            // 
            // ANALYZERCONFIGURATIONToolStripMenuItem
            // 
            this.ANALYZERCONFIGURATIONToolStripMenuItem.Name = "ANALYZERCONFIGURATIONToolStripMenuItem";
            this.ANALYZERCONFIGURATIONToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.ANALYZERCONFIGURATIONToolStripMenuItem.Text = "Comm. Port Configuration";
            this.ANALYZERCONFIGURATIONToolStripMenuItem.Click += new System.EventHandler(this.ANALYZERCONFIGURATIONToolStripMenuItem_Click);
            // 
            // portConfigurationToolStripMenuItem
            // 
            this.portConfigurationToolStripMenuItem.Name = "portConfigurationToolStripMenuItem";
            this.portConfigurationToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.portConfigurationToolStripMenuItem.Text = "About";
            this.portConfigurationToolStripMenuItem.Click += new System.EventHandler(this.portConfigurationToolStripMenuItem_Click);
            // 
            // notifyIconLISA
            // 
            this.notifyIconLISA.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIconLISA.Icon")));
            this.notifyIconLISA.Text = "LISA";
            this.notifyIconLISA.Click += new System.EventHandler(this.notifyIconLISA_Click);
            // 
            // button_reload
            // 
            this.button_reload.BackColor = System.Drawing.Color.Cornsilk;
            this.button_reload.Font = new System.Drawing.Font("Cambria", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_reload.Location = new System.Drawing.Point(820, 3);
            this.button_reload.Name = "button_reload";
            this.button_reload.Size = new System.Drawing.Size(59, 21);
            this.button_reload.TabIndex = 6;
            this.button_reload.Text = "Reload";
            this.button_reload.UseVisualStyleBackColor = false;
            this.button_reload.Click += new System.EventHandler(this.button_reload_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(923, 426);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AnalyzerDetails);
            this.Controls.Add(this.panel_header);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LISA";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.panel_header.ResumeLayout(false);
            this.panel_header.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_header;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_minimize;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.FlowLayoutPanel AnalyzerDetails;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lISASETUPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ANALYZERCONFIGURATIONToolStripMenuItem;
        private System.Windows.Forms.NotifyIcon notifyIconLISA;
        private System.Windows.Forms.ToolStripMenuItem portConfigurationToolStripMenuItem;
        private System.Windows.Forms.Button button_reload;
    }
}

