﻿using System;
using System.Data.OleDb;
using System.Configuration;
using System.Data;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using Npgsql;



namespace LISA
{
    class CONNECTION
    {

        private string strsqlconstring;

        private static string db_type;

        private MySqlConnection conn;

        private MySqlCommand sqlcom;

        private MySqlDataReader dr;

        private MySqlTransaction sqlTrans;

        private OleDbConnection Acccon;

        private OleDbCommand AccCom;

        private OleDbDataReader Accdr;

        private OleDbTransaction OledbTrans;

        private DataTable dt;

        private NpgsqlConnection conn1;
        private NpgsqlCommand command;
        private NpgsqlDataReader reader;


        public CONNECTION()
		{
            db_type = ConfigurationManager.AppSettings["DB_SYTEM"].ToString();
            if (db_type == "MySqlconnection")
            {
                conn = new MySqlConnection();
                conn = new MySqlConnection(ConfigurationManager.AppSettings["MySqlconnection"].ToString());
                strsqlconstring = ConfigurationManager.AppSettings["MySqlconnection"].ToString();
            }
            else
            {
                conn1 = new NpgsqlConnection();
                conn1 = new NpgsqlConnection(ConfigurationManager.AppSettings["Npgsqlconn"].ToString());
                strsqlconstring = ConfigurationManager.AppSettings["Npgsqlconn"].ToString();
            }
           
        }

        public DataTable GetDataTable(string str)
        {
            try
            {
                if (db_type == "MySqlconnection")
                {
                    conn.Open();
                    sqlcom = new MySqlCommand(str, conn);
                    dr = sqlcom.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(dr);
                    conn.Close();

                    return dt;
                }
                else
                {
                    conn1.Open();
                    command = new NpgsqlCommand(str, conn1);
                    reader = command.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(reader);
                    conn1.Close();

                    return dt;
                }
                

            }
            catch (Exception ex)
            {
                StreamWriter streamWriter = File.AppendText(Application.StartupPath + "\\logfile.txt");
                streamWriter.WriteLine(DateTime.Now.ToString() + ":" + str + "-" + ex.Message);
                streamWriter.Close();
                throw ex;
            }

            finally
            {

            }
        }

        public void ExecuteNonQuery(string StrQuery)
        {
            try
            {
                if (db_type == "MySqlconnection")
                {
                    using (conn = new MySqlConnection(strsqlconstring))
                    {
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }

                        conn.Open();
                        using (sqlcom = new MySqlCommand())
                        {
                            sqlcom.CommandType = CommandType.Text;
                            sqlcom.Connection = conn;
                            sqlcom.CommandText = StrQuery;
                            sqlcom.ExecuteNonQuery();
                        }
                    }
                }
                else
                {
                    using (conn1 = new NpgsqlConnection(strsqlconstring))
                    {
                        if (conn1.State == ConnectionState.Open)
                        {
                            conn1.Close();
                        }

                        conn1.Open();

                        using (command = new NpgsqlCommand())
                        {
                            command.CommandType = CommandType.Text;
                            command.Connection = conn1;
                            command.CommandText = StrQuery;
                            command.ExecuteNonQuery();
                        }
                        conn1.Close();
                    }
                }
            }

            catch (Exception ex)
            {
                StreamWriter streamWriter = File.AppendText(Application.StartupPath + "\\logfile_Mysql_postgres.txt");
                streamWriter.WriteLine(DateTime.Now.ToString() + " + ExecuteNonQuery + " + ex.Message);
                streamWriter.WriteLine(StrQuery.ToString());
                streamWriter.Close();
            }
        }



    }
}
