﻿
namespace LISA
{
    partial class UserControlAnalyzer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label_analyzer = new System.Windows.Forms.Label();
            this.label_port = new System.Windows.Forms.Label();
            this.label_machinename = new System.Windows.Forms.Label();
            this.richTextBox_analyzerString = new System.Windows.Forms.RichTextBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Turquoise;
            this.flowLayoutPanel1.Controls.Add(this.tableLayoutPanel1);
            this.flowLayoutPanel1.Controls.Add(this.richTextBox_analyzerString);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(387, 135);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Pink;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.48032F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.51968F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_analyzer, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label_port, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_machinename, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(381, 33);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(3, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "PORT NUMBER      :";
            // 
            // label_analyzer
            // 
            this.label_analyzer.AutoSize = true;
            this.label_analyzer.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_analyzer.ForeColor = System.Drawing.Color.Navy;
            this.label_analyzer.Location = new System.Drawing.Point(3, 0);
            this.label_analyzer.Name = "label_analyzer";
            this.label_analyzer.Size = new System.Drawing.Size(104, 14);
            this.label_analyzer.TabIndex = 0;
            this.label_analyzer.Text = "ANALYZER  NAME  :";
            // 
            // label_port
            // 
            this.label_port.AutoSize = true;
            this.label_port.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_port.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label_port.Location = new System.Drawing.Point(222, 16);
            this.label_port.Name = "label_port";
            this.label_port.Size = new System.Drawing.Size(83, 14);
            this.label_port.TabIndex = 1;
            this.label_port.Text = "PORT NUMBER";
            // 
            // label_machinename
            // 
            this.label_machinename.AutoSize = true;
            this.label_machinename.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_machinename.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label_machinename.Location = new System.Drawing.Point(222, 0);
            this.label_machinename.Name = "label_machinename";
            this.label_machinename.Size = new System.Drawing.Size(92, 14);
            this.label_machinename.TabIndex = 2;
            this.label_machinename.Text = "ANALYZER NAME";
            // 
            // richTextBox_analyzerString
            // 
            this.richTextBox_analyzerString.BackColor = System.Drawing.SystemColors.HighlightText;
            this.richTextBox_analyzerString.Font = new System.Drawing.Font("Calibri", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.richTextBox_analyzerString.ForeColor = System.Drawing.Color.DarkGreen;
            this.richTextBox_analyzerString.Location = new System.Drawing.Point(3, 42);
            this.richTextBox_analyzerString.Name = "richTextBox_analyzerString";
            this.richTextBox_analyzerString.Size = new System.Drawing.Size(381, 90);
            this.richTextBox_analyzerString.TabIndex = 0;
            this.richTextBox_analyzerString.Text = "";
            // 
            // UserControlAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "UserControlAnalyzer";
            this.Size = new System.Drawing.Size(387, 135);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RichTextBox richTextBox_analyzerString;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label_analyzer;
        private System.Windows.Forms.Label label_port;
        private System.Windows.Forms.Label label_machinename;
        private System.Windows.Forms.Label label1;
    }
}
