using System;
using System.Data;
using System.IO;
using System.Text;
using System.Configuration;



namespace LISA
{
    public class ANALYZEROUTPUT
    {
        
        private string strCreatedDttm;

        private string strCreatedBy;

        private string strLastModifiedDttm;

        private string strLastModifiedBy;

        private CONNECTION objCONNECTION;

        private int intLISA_ID;

        private string intLISAA_ID;

        private string strLISA_NAME;

        private string strLISA_LabID;

        private string strLISA_TESTID;

        private string strLISA_Results;

        private string strLISA_Alarm;

        private string strLISA_Units;

        private int intLISA_Reviewed;

        private int intLISA_Status;

        private string strLISA_IsRepeated;

        private int intLISA_PatientRQC;

        private string dttLISA_CreatedDttm;

        private string strLISA_CreatedBy;

        private string dttLISA_LastModifiedDttm;

        private string strLISA_LastModifiedBy;

        private string strLISA_Direction;

        private string _LISA_SamTypeID;

        private string _LISA_SamType;

        private string strbinarydata;

        private static DataTable dataTableMachineId;

        public string CreatedDttm
        {
            get
            {
                return strCreatedDttm;
            }
            set
            {
                strCreatedDttm = value;
            }
        }

        public string CreatedBy
        {
            get
            {
                return strCreatedBy;
            }
            set
            {
                strCreatedBy = value;
            }
        }

        public string LastModifiedDttm
        {
            get
            {
                return strLastModifiedDttm;
            }
            set
            {
                strLastModifiedDttm = value;
            }
        }

        public string LastModifiedBy
        {
            get
            {
                return strLastModifiedBy;
            }
            set
            {
                strLastModifiedBy = value;
            }
        }

        public string LISA_SamTypeID
        {
            get
            {
                return _LISA_SamTypeID;
            }
            set
            {
                _LISA_SamTypeID = value;
            }
        }

        public string LISA_SamType
        {
            get
            {
                return _LISA_SamType;
            }
            set
            {
                _LISA_SamType = value;
            }
        }

        public string LISA_TestID
        {
            get
            {
                return strLISA_TESTID;
            }
            set
            {
                strLISA_TESTID = value;
            }
        }

        public string LISA_ID
        {
            get
            {
                return intLISAA_ID;
            }
            set
            {
                intLISAA_ID = value;
            }
        }

        public string LISA_LabID
        {
            get
            {
                return strLISA_LabID;
            }
            set
            {
                strLISA_LabID = value;
            }
        }

        public string LISA_Results
        {
            get
            {
                return strLISA_Results;
            }
            set
            {
                strLISA_Results = value;
            }
        }

        public string LISA_Units
        {
            get
            {
                return strLISA_Units;
            }
            set
            {
                strLISA_Units = value;
            }
        }

        public string LISA_Alarm
        {
            get
            {
                return strLISA_Alarm;
            }
            set
            {
                strLISA_Alarm = value;
            }
        }

        public int LISA_Reviewed
        {
            get
            {
                return intLISA_Reviewed;
            }
            set
            {
                intLISA_Reviewed = value;
            }
        }

        public int LISA_Status
        {
            get
            {
                return intLISA_Status;
            }
            set
            {
                intLISA_Status = value;
            }
        }

        public int LISA_PatientRQC
        {
            get
            {
                return intLISA_PatientRQC;
            }
            set
            {
                intLISA_PatientRQC = value;
            }
        }

        public string LISA_CreatedDttm
        {
            get
            {
                return dttLISA_CreatedDttm;
            }
            set
            {
                dttLISA_CreatedDttm = value;
            }
        }

        public string LISA_IsRepeated
        {
            get
            {
                return strLISA_IsRepeated;
            }
            set
            {
                strLISA_IsRepeated = value;
            }
        }

        public string LISA_Direction
        {
            get
            {
                return strLISA_Direction;
            }
            set
            {
                strLISA_Direction = value;
            }
        }

        public string LISA_CreatedBy
        {
            get
            {
                return strLISA_CreatedBy;
            }
            set
            {
                strLISA_CreatedBy = value;
            }
        }

        public string LISA_binarydata
        {
            get
            {
                return strbinarydata;
            }
            set
            {
                strbinarydata = value;
            }
        }

        public string LISA_LastModifiedDttm
        {
            get
            {
                return dttLISA_LastModifiedDttm;
            }
            set
            {
                dttLISA_LastModifiedDttm = string.Format("dd/MM/yyyy hh:mm:ss tt", value);
            }
        }

        public string LISA_LastModifiedBy
        {
            get
            {
                return strLISA_LastModifiedBy;
            }
            set
            {
                strLISA_LastModifiedBy = value;
            }
        }

        public string LISA_NAME
        {
            get
            {
                return strLISA_NAME;
            }
            set
            {
                strLISA_NAME = value;
            }
        }

        public void MachineResultOutput(string Op)
        {
            string machine_id = string.Empty;
            objCONNECTION = new CONNECTION();
            dataTableMachineId = objCONNECTION.GetDataTable("SELECT mana_machinenameid as machinenameid FROM lb_mana_machinename WHERE mana_machinename='" + LISA_NAME.Trim() + "'");

            if (dataTableMachineId.Rows.Count > 0)
            {
                machine_id = dataTableMachineId.Rows[0]["machinenameid"].ToString().Trim();
            }
            else
            {
                machine_id = "0";
            }

            if (Op == "INSERT_RESULT")
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append("Insert into device_result");
                stringBuilder.Append("(device_name,device_id,accession_number,online_testcode,test_result");
                stringBuilder.Append(") values");
                stringBuilder.Append("('" + LISA_NAME + "',");
                stringBuilder.Append(machine_id + ",");
                stringBuilder.Append("'" + LISA_LabID + "',");
                stringBuilder.Append("'" + strLISA_TESTID + "',");
                stringBuilder.Append("'" + strLISA_Results + "'" + ")");
                //stringBuilder.Append("'" + $"{DateTime.Now:yyyyMMddHHmmss}" + "')");
                objCONNECTION.ExecuteNonQuery(stringBuilder.ToString());
            }
        }
    }
}
