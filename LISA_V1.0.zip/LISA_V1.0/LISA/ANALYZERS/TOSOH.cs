using System;
using System.Data;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Text.RegularExpressions;
using MySqlX.XDevAPI.Common;
using System.Linq;

namespace LISA
{
	public class TOSOH : LISAINTERFACE_SERIAL
	{
		private ASCIIEncoding asen = new ASCIIEncoding();

		private static string strQueryID;

		private static string strDataReceived;

		private static string QPatientID;

		private static string RPatientID;

		private int eot = 0;

		private char sendChar = '0';

		private long CheckSumValue;

		private string strETB;

		private static string strLI_SaveString;

        private ANALYZEROUTPUT objAnalyzerOutput = new ANALYZEROUTPUT();

        private CONNECTION objCONNECTION;

		private static string strETBstring;

		public static string OrderString = null;

		private int intStatus = 0;

		private string strDispPatientid = null;

		private string strSampleCode = null;

		private string logmid;

		private string MachineID;

		private StreamWriter sw;

		private static DataTable dataTable;

		private static int frameNumber = 0;

		private static DataTable DTPtdetail;

		public string LI_ETB
		{
			get
			{
				return strETB;
			}
			set
			{
				strETB = value;
			}
		}

		public string LI_RPatientID
		{
			get
			{
				return RPatientID;
			}
			set
			{
				RPatientID = value;
			}
		}

		public static string LI_SaveString
		{
			get
			{
				return strLI_SaveString;
			}
			set
			{
				strLI_SaveString = value;
			}
		}

		public static string LI_DataReceived
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public long LI_CheckSumValue
		{
			get
			{
				return CheckSumValue;
			}
			set
			{
				CheckSumValue = value;
			}
		}

		public string LI_QueryPatientID
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public string LI_ResultPatientID
		{
			get
			{
				return RPatientID;
			}
			set
			{
				RPatientID = value;
			}
		}

		public int LI_Eot
		{
			get
			{
				return eot;
			}
			set
			{
				eot = value;
			}
		}

		public char LI_SendChar
		{
			get
			{
				return sendChar;
			}
			set
			{
				sendChar = value;
			}
		}

		public string LI_SampleCode
		{
			get
			{
				return strSampleCode;
			}
			set
			{
				strSampleCode = value;
			}
		}

		public static string LI_QPatientID
		{
			get
			{
				return QPatientID;
			}
			set
			{
				QPatientID = value;
			}
		}

		public int LI_InterfaceStatus
		{
			get
			{
				return intStatus;
			}
			set
			{
				intStatus = value;
			}
		}

		public string LI_DispPatientID
		{
			get
			{
				return strDispPatientid;
			}
			set
			{
				strDispPatientid = value;
			}
		}

		public static string LI_ETBstring
		{
			get
			{
				return strETBstring;
			}
			set
			{
				strETBstring = value;
			}
		}

		public static string LI_strDataReceived
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public string LI_Machineidlog
		{
			get
			{
				return logmid;
			}
			set
			{
				logmid = value;
			}
		}

		public TOSOH(string mid)
		{
			MachineID = mid;
		}

		public void ParseData_Serial(string strReceived, SerialPort sPort)
		{

            //sw = File.AppendText(Application.StartupPath + "\\TOSOH_strReceived.log");
            //sw.WriteLine(DateTime.Now.ToString() +":"+ strReceived);
            //sw.Close();

            try
            {
                if(strReceived.Contains("\r\n    \r\n"))
				{
					strReceived = strReceived.Replace("\r\n    \r\n", "").Replace("\r", "").Replace("\n", "");
				}
				else if (strReceived.Contains("\r\n"))
				{
					strReceived = strReceived.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
				}

				if (strReceived.Contains("SampleID") && strReceived.Contains("Date"))
				{

					string[] array = strReceived.Split(new string[] { "SampleID=" }, StringSplitOptions.None);
					array = array.Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();


					for (int i = 0; i <= array.Length - 1; i++)
					{
						array[i] = "SampleID=" + array[i];


						if (array[i].Contains("SampleID") && array[i].Contains("Date"))
						{
							string[] source = Regex.Split(array[i].Trim(), ",");

							objAnalyzerOutput.LISA_LabID = source[1].Trim();
							LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
							objAnalyzerOutput.LISA_ID = "LISA";
							objAnalyzerOutput.LISA_NAME = "TOSOH";
							objAnalyzerOutput.LISA_Alarm = ".";
							objAnalyzerOutput.LISA_Direction = "BIDIRECTIONAL";
							objAnalyzerOutput.LISA_Alarm = string.Empty;
							objAnalyzerOutput.LISA_Units = string.Empty;
							LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
							objAnalyzerOutput.LISA_Results = source[5].ToString().Trim();
							objAnalyzerOutput.LISA_TestID = source[3].ToString().Trim();

							if (objAnalyzerOutput.LISA_Results != "-" && objAnalyzerOutput.LISA_Results != "")
							{
								objAnalyzerOutput.MachineResultOutput("INSERT_RESULT");
							}
						}
					}

				}
				else
				{
					strDataReceived += strReceived;

                    if (strDataReceived.Contains("SampleID") && strDataReceived.Contains("Date"))
                    {

                        string[] array = strDataReceived.Split(new string[] { "SampleID=" }, StringSplitOptions.None);
                        array = array.Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();

						strDataReceived = "";

                        for (int i = 0; i <= array.Length - 1; i++)
                        {
                            array[i] = "SampleID=" + array[i];

                         
                            if (array[i].Contains("SampleID") && array[i].Contains("Date"))
                            {
                                string[] source = Regex.Split(array[i].Trim(), ",");

                                objAnalyzerOutput.LISA_LabID = source[1].Trim();
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                                objAnalyzerOutput.LISA_ID = "LISA";
                                objAnalyzerOutput.LISA_NAME = "TOSOH";
                                objAnalyzerOutput.LISA_Alarm = ".";
                                objAnalyzerOutput.LISA_Direction = "BIDIRECTIONAL";
                                objAnalyzerOutput.LISA_Alarm = string.Empty;
                                objAnalyzerOutput.LISA_Units = string.Empty;
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                                objAnalyzerOutput.LISA_Results = source[5].ToString().Trim();
                                objAnalyzerOutput.LISA_TestID = source[3].ToString().Trim();

                                if (objAnalyzerOutput.LISA_Results != "-" && objAnalyzerOutput.LISA_Results != "")
                                {
                                    objAnalyzerOutput.MachineResultOutput("INSERT_RESULT");
                                }
                            }
                        }

                    }
                }


			}
			catch (Exception ex)
			{
				sw = File.AppendText(Application.StartupPath + "\\TOSOH_Log.log");
				sw.WriteLine(DateTime.Now.ToString() + " : ErrorQuery : " + ex.Message);
				sw.Close();
			}
		}

		public void CheckSum(string st)
		{
			try
			{
				int x = 0;
				for (int i = 0; i <= st.Length - 1; i++)
				{
					x += Asc(Convert.ToChar(st.Substring(i, 1).ToString()));
				}
				CheckSumValue = x;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private int Asc(char p)
		{
			int num = p;
			return Convert.ToInt32(num.ToString());
		}
	}
}
