﻿using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Globalization;

namespace LISA
{
	public class YUMIZEN_H550 : LISAINTERFACE_NETWORK
	{

		private static DataTable DTOrder;

		private static int eot = 0;

		private static string strQueryID;

		private bool bFlag = false;

		public static string strDataReceived = null;

		private string MachID = null;

		private static string DI_SAMPLEQUERYID = null;

		private static string strLI_SaveString;

		private static string strETBstring;

		private byte[] Msg = new byte[1024];

		private long CheckSumValue;

		private static List<string> barcodes = new List<string>();

		private CONNECTION objCONNECTION;

		private StreamWriter sw;

		private string strDispPatientid = null;

        private ANALYZEROUTPUT objAnalyzerOutput = new ANALYZEROUTPUT();

        private static DataTable DTPtdetail;

		private static string str_barcodeno = null;

		public string LI_DispPatientID
		{
			get
			{
				return strDispPatientid;
			}
			set
			{
				strDispPatientid = value;
			}
		}
		public static string LI_SaveString
		{
			get
			{
				return strLI_SaveString;
			}
			set
			{
				strLI_SaveString = value;
			}
		}

		public static string LI_ETBstring
		{
			get
			{
				return strETBstring;
			}
			set
			{
				strETBstring = value;
			}
		}

		public static string DI_QUERYID
		{
			get
			{
				return DI_SAMPLEQUERYID;
			}
			set
			{
				DI_SAMPLEQUERYID = value;
			}
		}

		public YUMIZEN_H550(string AnalyserId)
		{
			MachID = AnalyserId.ToString();
		}

		public void ParseDataTCP_Server(string bytes, NetworkStream Client)
		{
            string update_ptd = ConfigurationManager.AppSettings["LOG_SYSTEM"].ToString();  //Maintaining the logs

            if (update_ptd == "TRUE")
            {
                sw = File.AppendText(Application.StartupPath + "\\YUMIZEN_H550_AnalyserQuery.log");
                sw.WriteLine("DateTime: " + DateTime.Now.ToString() + "  R:" + bytes);
                sw.Close();
            }

            try
			{
				for (int i = 0; i <= bytes.Length - 1; i++)
				{
					char chrReceive = Convert.ToChar(bytes.Substring(i, 1));

					switch (chrReceive)
					{
						case '\u0002':
							strDataReceived = string.Empty;
							break;

						case '\u0005':
							Msg = Encoding.ASCII.GetBytes('\u0006'.ToString());
							Client.Write(Msg, 0, Msg.Length);
							break;


						case '\u0004':
							Msg = Encoding.ASCII.GetBytes('\u0006'.ToString());
							Client.Write(Msg, 0, Msg.Length);
							break;

						case '\u0017':
							Msg = Encoding.ASCII.GetBytes('\u0006'.ToString());
							Client.Write(Msg, 0, Msg.Length);
							if (strDataReceived != null || strDataReceived != string.Empty)
							{
								LI_ETBstring = strDataReceived.Substring(0, strDataReceived.Length - 1);
								LI_SaveString += LI_ETBstring;
								LI_ETBstring = string.Empty;
								strDataReceived = string.Empty;
							}
							break;

						case '\u0003':
							Msg = Encoding.ASCII.GetBytes('\u0006'.ToString());
							Client.Write(Msg, 0, Msg.Length);

							if (strDataReceived != null || strDataReceived != string.Empty)
							{

								LI_ETBstring = strDataReceived.Substring(1, strDataReceived.Length-1); ;
								LI_SaveString += LI_ETBstring;
								SaveData(LI_SaveString);
							}

							strDataReceived = string.Empty;
							LI_SaveString = string.Empty;
							LI_ETBstring = string.Empty;
							break;

						default:
							strDataReceived += chrReceive.ToString();
							break;

						
					}
				}
			}
			catch (Exception ex)
			{
				sw = File.AppendText(Application.StartupPath + "\\YUMIZEN_H550_Error_Log.log");
				sw.WriteLine(DateTime.Now.ToString() + " : QueryStore : " + ex.Message);
				sw.Close();
			}

		}

		public void SaveData(string strSTFReceivedText)
		{
			string[] array = null;
			string[] array2 = null;
			string[] array3 = null;
			string[] array4 = null;
			string[] array5 = null;
			

			try
			{
				array = strSTFReceivedText.Split('\r');
				for (int i = 0; i <= array.Length - 1; i++)
				{
					if (array[i].Length <= 1)
					{
						continue;
					}
					switch (array[i].Substring(0, 1))
					{
						case "H":
							break;

						case "P":
							break;

						case "O":
							array4 = array[i].Split('|');
							objAnalyzerOutput.LISA_LabID = array4[2].ToString().Split('^')[0].ToString().Trim(); ;
							LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
							str_barcodeno = objAnalyzerOutput.LISA_LabID;
							break;

						case "R":
							array5 = array[i].Split('|');
							objAnalyzerOutput.LISA_LabID = str_barcodeno;
							LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
							objAnalyzerOutput.LISA_ID = "LISA";
							objAnalyzerOutput.LISA_NAME = "YUMIZEN_H550";
							objAnalyzerOutput.LISA_Alarm = ".";
							objAnalyzerOutput.LISA_Direction = "BIDIRECTIONAL";
							objAnalyzerOutput.LISA_TestID = array5[2].ToString().Split('^')[3];
							objAnalyzerOutput.LISA_Results = array5[3].ToString().Trim();
							objAnalyzerOutput.LISA_Alarm = String.Empty;
							objAnalyzerOutput.LISA_Units = String.Empty;

							if (objAnalyzerOutput.LISA_Results != "-" && objAnalyzerOutput.LISA_Results != "-----" && objAnalyzerOutput.LISA_Results != "")
							{

                                objAnalyzerOutput.MachineResultOutput("INSERT_RESULT");
                            }
							break;

						
					}
				}
			}
			catch (Exception ex)
			{
				sw = File.AppendText(Application.StartupPath + "\\HORIBA_HEMATOLOGY_Error_Log.log");
				sw.WriteLine(DateTime.Now.ToString() + " : QueryData : " + ex.Message);
				sw.Close();
			}
		}

	}
}
