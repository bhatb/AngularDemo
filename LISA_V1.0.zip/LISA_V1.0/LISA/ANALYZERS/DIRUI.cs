using System;
using System.Data;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Text.RegularExpressions;
using MySqlX.XDevAPI.Common;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace LISA
{
	public class DIRUI : LISAINTERFACE_SERIAL
	{
		private ASCIIEncoding asen = new ASCIIEncoding();

		private static string strQueryID;

		private static string strDataReceived;

		private static string QPatientID;

		private static string RPatientID;

		private int eot = 0;

		private char sendChar = '0';

		private long CheckSumValue;

		private string strETB;

		private static string strLI_SaveString;

        private ANALYZEROUTPUT objAnalyzerOutput = new ANALYZEROUTPUT();

        private CONNECTION objCONNECTION;

		private static string strETBstring;

		public static string OrderString = null;

		private int intStatus = 0;

		private string strDispPatientid = null;

		private string strSampleCode = null;

		private string logmid;

		private string MachineID;

		private StreamWriter sw;

		private static DataTable dataTable;

		private static int frameNumber = 0;

		private static DataTable DTPtdetail;

		public string LI_ETB
		{
			get
			{
				return strETB;
			}
			set
			{
				strETB = value;
			}
		}

		public string LI_RPatientID
		{
			get
			{
				return RPatientID;
			}
			set
			{
				RPatientID = value;
			}
		}

		public static string LI_SaveString
		{
			get
			{
				return strLI_SaveString;
			}
			set
			{
				strLI_SaveString = value;
			}
		}

		public static string LI_DataReceived
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public long LI_CheckSumValue
		{
			get
			{
				return CheckSumValue;
			}
			set
			{
				CheckSumValue = value;
			}
		}

		public string LI_QueryPatientID
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public string LI_ResultPatientID
		{
			get
			{
				return RPatientID;
			}
			set
			{
				RPatientID = value;
			}
		}

		public int LI_Eot
		{
			get
			{
				return eot;
			}
			set
			{
				eot = value;
			}
		}

		public char LI_SendChar
		{
			get
			{
				return sendChar;
			}
			set
			{
				sendChar = value;
			}
		}

		public string LI_SampleCode
		{
			get
			{
				return strSampleCode;
			}
			set
			{
				strSampleCode = value;
			}
		}

		public static string LI_QPatientID
		{
			get
			{
				return QPatientID;
			}
			set
			{
				QPatientID = value;
			}
		}

		public int LI_InterfaceStatus
		{
			get
			{
				return intStatus;
			}
			set
			{
				intStatus = value;
			}
		}

		public string LI_DispPatientID
		{
			get
			{
				return strDispPatientid;
			}
			set
			{
				strDispPatientid = value;
			}
		}

		public static string LI_ETBstring
		{
			get
			{
				return strETBstring;
			}
			set
			{
				strETBstring = value;
			}
		}

		public static string LI_strDataReceived
		{
			get
			{
				return strDataReceived;
			}
			set
			{
				strDataReceived = value;
			}
		}

		public string LI_Machineidlog
		{
			get
			{
				return logmid;
			}
			set
			{
				logmid = value;
			}
		}

		public DIRUI(string mid)
		{
			MachineID = mid;
		}

		public void ParseData_Serial(string strReceived, SerialPort sPort)
		{
            try
			{
				objAnalyzerOutput.LISA_LabID = "";
				objAnalyzerOutput.LISA_TestID = "";


                for (int k = 0; k <= strReceived.Length-1; k++) 
				{
					char c = Convert.ToChar(strReceived.Substring(k, 1));
					switch (c)
					{
					case '\u0002':
						strDataReceived = null;
						break;


					case '\u0003':
						if (strDataReceived != null || strDataReceived != string.Empty)
						{
							LI_ETBstring = strDataReceived.Substring(0, strDataReceived.Length);
							LI_SaveString += LI_ETBstring;

							if (LI_SaveString != string.Empty)
							{
								if (LI_SaveString.Contains("\r\n \r\n"))
								{
									LI_SaveString = LI_SaveString.Replace("\r\n\r\n", ";").Replace("\r\n \r\n", ";").Replace("\r", "").Replace("\n", "");
								}
								else if (LI_SaveString.Contains("\r\n"))
								{
									LI_SaveString = LI_SaveString.Replace("\r\n", ";").Replace("\r", "").Replace("\n", "");
								}

								string[] source = LI_SaveString.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
								source = source.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();

								source = Regex.Split(source[0].ToString(), ";");
								source = source.Where((string x) => !string.IsNullOrEmpty(x)).ToArray();

								for (int i = 0; i < source.Length; i++)
								{
									source[i] = source[i].Trim();
									source[i].Trim().Replace("\n", string.Empty);
									source[i].Trim().Replace("\r", string.Empty);
									source[i].Trim().Replace("\t", string.Empty);
									source = source.Where((string x) => !string.IsNullOrEmpty(x)).ToArray();

									if (source[i].Trim().Contains("ID:"))
									{
										source[i] = source[i].Trim();
										string[] array = Regex.Split(source[i], ":");
										objAnalyzerOutput.LISA_LabID = Regex.Replace(array[1].ToString().Trim(), "[^0-9]", "");
									}
									else if (source[i].Trim().Contains("UBG"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "UBG";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("umol/L", "").Replace("*", "").Trim();
                                        objAnalyzerOutput.LISA_Units = "umol/L";
									}
									else if (source[i].Trim().Contains("BIL"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "BIL";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
                                        
									}
									else if (source[i].Trim().Contains("KET"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "KET";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
									}
									else if (source[i].Trim().Contains("BLD"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "BLD";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("Ery/uL", "").Replace("*", "").Trim();
										objAnalyzerOutput.LISA_Units = "Ery/uL";
									}
									else if (source[i].Trim().Contains("PRO"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "PRO";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("g/L", "").Replace("*", "").Trim();
										objAnalyzerOutput.LISA_Units = "g/L";
									}
									else if (source[i].Trim().Contains("NIT"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "NIT";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
									}
									else if (source[i].Trim().Contains("LEU"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "LEU";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("Leu/uL", "").Replace("*", "").Trim();
										objAnalyzerOutput.LISA_Units = "Leu/uL";
									}
									else if (source[i].Trim().Contains("GLU"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "GLU";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
									}
									else if (source[i].Trim().Contains("SG"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "SG";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
									}
									else if (source[i].Trim().Contains("pH"))
									{
										source[i] = source[i].Trim();
										objAnalyzerOutput.LISA_TestID = "pH";
										objAnalyzerOutput.LISA_Results = source[i].Trim().Replace(objAnalyzerOutput.LISA_TestID, "").Replace("*", "").Trim();
									}
									else if (source[i].Trim().Contains("Color"))
									{
										source[i] = source[i].Trim();
										string[] source3 = Regex.Split(source[i], ":");
										objAnalyzerOutput.LISA_TestID = Regex.Replace(source3[0].Trim(), "[^a-zA-Z]", "");
										objAnalyzerOutput.LISA_Results = source3[1].ToString().Trim();
									}
									else if (source[i].Trim().Contains("Clarity"))
									{
										source[i] = source[i].Trim();
										string[] source3 = Regex.Split(source[i], ":");
										objAnalyzerOutput.LISA_TestID = Regex.Replace(source3[0].Trim(), "[^a-zA-Z]", "");
										objAnalyzerOutput.LISA_Results = Regex.Replace(source3[1].Trim(), "[^a-zA-Z0-9.]", "");
										
									}


									if (objAnalyzerOutput.LISA_LabID.Trim() != "" && objAnalyzerOutput.LISA_TestID.Trim() != "")
									{


										LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
										objAnalyzerOutput.LISA_ID = "LISA";
										objAnalyzerOutput.LISA_NAME = "DIRUI";
										objAnalyzerOutput.LISA_Alarm = ".";
										objAnalyzerOutput.LISA_Direction = "BIDIRECTIONAL";
										objAnalyzerOutput.LISA_Alarm = string.Empty;

										objAnalyzerOutput.MachineResultOutput("INSERT_RESULT");
										objAnalyzerOutput.LISA_TestID = "";

									}

								}


                            }


						}
						strDataReceived = string.Empty;
						LI_SaveString = string.Empty;
						LI_ETBstring = string.Empty;
						break;

					default:
						strDataReceived += c;
						break;


					}

				}

			}
			catch (Exception ex) 
			{
                sw = File.AppendText(System.Windows.Forms.Application.StartupPath + "\\DIRUI_Log.log");
                sw.WriteLine(DateTime.Now.ToString() + " : ErrorQuery : " + ex.Message);
                sw.Close();
            }

        }

		
	}
}
