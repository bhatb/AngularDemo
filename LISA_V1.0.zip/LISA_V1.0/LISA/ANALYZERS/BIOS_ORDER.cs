using System;
using System.Data;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Configuration;
using System.Net.Sockets;
using System.Globalization;
using MySqlX.XDevAPI;
using System.Net;

namespace LISA
{
    public class BIOS_ORDER : LISAINTERFACE_NETWORK
    {
        private ASCIIEncoding asen = new ASCIIEncoding();

        private static string strQueryID;

        private static string strDataReceived;

        private static string QPatientID;

        private static string RPatientID;

        private int eot = 0;

        private char sendChar = '0';

        private long CheckSumValue;

        private bool boolSendTest = false;

        private static bool boolETB;

        private string strETB;

        private static string strLI_SaveString;

        private ANALYZEROUTPUT objAnalyzerOutput = new ANALYZEROUTPUT();

        private CONNECTION objCONNECTION;

        private static string strETBstring;

        private static string strSaveString;

        private int intStatus = 0;

        private string strDispPatientid = null;

        private string strSampleCode = null;

        private static string MsgType;

        private static string MsgId;

        private static string MsgId2;


        private string logmid;

        private string str;

        private string MachineID;

        private string strTestOrder;

        private byte[] ba;

        private StreamWriter sw;

        private StringBuilder sb;

        private byte[] Msg = new byte[1024];

        private static DataTable dataTable;

        private static DataTable DTPtdetail;

        private static string ResponseData = null;

        public string LI_ETB
        {
            get
            {
                return strETB;
            }
            set
            {
                strETB = value;
            }
        }

        public string LI_RPatientID
        {
            get
            {
                return RPatientID;
            }
            set
            {
                RPatientID = value;
            }
        }

        public static string LI_SaveString
        {
            get
            {
                return strLI_SaveString;
            }
            set
            {
                strLI_SaveString = value;
            }
        }

        public static string LI_DataReceived
        {
            get
            {
                return strDataReceived;
            }
            set
            {
                strDataReceived = value;
            }
        }

        public long LI_CheckSumValue
        {
            get
            {
                return CheckSumValue;
            }
            set
            {
                CheckSumValue = value;
            }
        }

        public string LI_QueryPatientID
        {
            get
            {
                return strDataReceived;
            }
            set
            {
                strDataReceived = value;
            }
        }

        public string LI_ResultPatientID
        {
            get
            {
                return RPatientID;
            }
            set
            {
                RPatientID = value;
            }
        }

        public int LI_Eot
        {
            get
            {
                return eot;
            }
            set
            {
                eot = value;
            }
        }

        public char LI_SendChar
        {
            get
            {
                return sendChar;
            }
            set
            {
                sendChar = value;
            }
        }

        public string LI_SampleCode
        {
            get
            {
                return strSampleCode;
            }
            set
            {
                strSampleCode = value;
            }
        }

        public static string LI_QPatientID
        {
            get
            {
                return QPatientID;
            }
            set
            {
                QPatientID = value;
            }
        }

        public int LI_InterfaceStatus
        {
            get
            {
                return intStatus;
            }
            set
            {
                intStatus = value;
            }
        }

        public string LI_DispPatientID
        {
            get
            {
                return strDispPatientid;
            }
            set
            {
                strDispPatientid = value;
            }
        }

        public static string LI_ETBstring
        {
            get
            {
                return strETBstring;
            }
            set
            {
                strETBstring = value;
            }
        }

        public static string LI_strDataReceived
        {
            get
            {
                return strDataReceived;
            }
            set
            {
                strDataReceived = value;
            }
        }

        public string LI_Machineidlog
        {
            get
            {
                return logmid;
            }
            set
            {
                logmid = value;
            }
        }

        public BIOS_ORDER(string mid)
        {
            MachineID = mid;
        }

        public void ParseDataTCP_Server(string strReceived, NetworkStream Client)
        {

            try
            {
                for (int i = 0; i <= strReceived.Length - 1; i++)
                {
                    char c = Convert.ToChar(strReceived.Substring(i, 1));
                    switch (c)
                    {
                        case '\v':
                            strDataReceived = null;
                            break;

                        case '\u001c':
                            {
                                SaveData(strDataReceived, Client);
                                string msgType = MsgType;
                                string text = msgType;

                                if (text == "QBP^WOS^QBP_Q11" && strQueryID != "1" && strQueryID !="")
                                {

                                    
                                }

                                strDataReceived = null;
                                LI_SaveString = null;
                                LI_ETBstring = null;
                                break;
                            }
                        default:
                            strDataReceived += c;
                            break;


                    }
                }
            }
            catch (Exception ex)
            {
                sw = File.AppendText(Application.StartupPath + "\\BIOS_PARSE_Log.log");
                sw.WriteLine(DateTime.Now.ToString() + " : ParseDataTCP_Server : " + ex.Message);
                sw.Close();
            }
        }

        public void SaveData(string strSTFReceivedText, NetworkStream Client)
        {
            string[] array = null;
            string[] array2 = null;
            string[] array3 = null;
            string[] array4 = null;
            string[] array5 = null;
            string[] array6 = null;
            string text = null;
            string[] array7 = null;
            string Processeddate = string.Empty;
            string IsQc2 = string.Empty;

            try
            {
                array = strSTFReceivedText.Split('\r');
                for (int i = 0; i <= array.Length - 1; i++)
                {
                    if (array[i].Length <= 1)
                    {
                        continue;
                    }
                    switch (array[i].Substring(0, 3))
                    {
                        case "MSH":
                            array2 = array[i].Split('|');
                            MsgType = array2[8];
                            MsgId2 = array2[9];
                            MsgId = array2[6].Split('^')[0];
                            break;

                        case "PID":
                            array3 = array[i].Split('|');
                            if (array3[3].Length > 0)
                            {
                                objAnalyzerOutput.LISA_LabID = array3[3].Split('^')[0].ToString().Trim();
                                objAnalyzerOutput.LISA_LabID = objAnalyzerOutput.LISA_LabID.Replace('_', '/');
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                            }
                            break;

                        case "SAC":
                            array4 = array[i].Split('|');
                            if (array4[3].Split('^')[0].Length > 0)
                            {
                                objAnalyzerOutput.LISA_LabID = array4[3].Split('^')[0].ToString().Trim();
                                objAnalyzerOutput.LISA_LabID = objAnalyzerOutput.LISA_LabID.Replace('_', '/');
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                            }
                            break;

                        case "OBX":
                            array5 = array[i].Split('|');
                            if (array5[2] == "CWE")
                            {
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                                objAnalyzerOutput.LISA_ID = "LISA";
                                objAnalyzerOutput.LISA_NAME = "BIOS";
                                objAnalyzerOutput.LISA_Alarm = ".";
                                objAnalyzerOutput.LISA_Direction = "BIDIRECTIONAL";
                                objAnalyzerOutput.LISA_Alarm = string.Empty;
                                objAnalyzerOutput.LISA_Units = string.Empty;
                                LI_DispPatientID = objAnalyzerOutput.LISA_LabID;
                                objAnalyzerOutput.LISA_Results = array5[5].Split('^')[0].ToString().Trim();
                                objAnalyzerOutput.LISA_TestID = array5[3].Split('^')[1].ToString().Trim();

                                if (objAnalyzerOutput.LISA_Results != "-")
                                {
                                    objAnalyzerOutput.MachineResultOutput("INSERT_RESULT");
                                }
                            }
                            break;

                        case "QPD":
                            {
                                array7 = array[i].Split('|');
                                if (!string.IsNullOrEmpty(array7[4].ToString().Trim()))
                                {
                                    strQueryID = array7[4].Split('^')[0].ToString().Trim();
                                }
                                else
                                {
                                    strQueryID = "1";
                                }
                                

                                string Patientid2 = null;
                                string Patientname2 = null;
                                string Age2 = null;
                                string gender2 = null;
                                string strTestList = null;

                                objCONNECTION = new CONNECTION();
                                dataTable = new DataTable();
                                dataTable = objCONNECTION.GetDataTable("SELECT online_testcode AS MachineTestID,accession_number AS LABID,patient_name,patient_id,gender FROM device_order WHERE isordersent= 'N' and device_name = 'BIOS' and accession_number='" + strQueryID.Trim() + "'");

                                if (dataTable.Rows.Count > 0)
                                {
                                    Patientid2 = dataTable.Rows[0]["patient_id"].ToString();
                                    Patientname2 = dataTable.Rows[0]["patient_name"].ToString();

                                    if (Patientname2.Length > 20)
                                    {
                                        Patientname2 = Patientname2.Substring(0, 20);
                                    }

                                    gender2 = dataTable.Rows[0]["gender"].ToString();

                                    if (gender2.Length > 1)
                                    {
                                        gender2 = gender2.Substring(0, 1).ToUpper();
                                    } 

                                    
                                    for (int k = 0; k <= dataTable.Rows.Count - 1; k++)
                                    {
                                        strTestList = strTestList + "OBX|" + (k + 1) + "||" + (k + 1) +"^" + dataTable.Rows[k]["MachineTestID"].ToString().Trim() + "||||||||\r";
                                    }

                                    sb = new StringBuilder();
                                    sb.Append("\vMSH|^~\\&|BiOLiS30i||Laboratory Information System||" + DateTime.Now.ToString("yyyyMMdd") + "||RSP^WOS^RSP_K11|" + MsgId + "||2.5||||||ASCII|||\r");
                                    sb.Append("MSA|AA|"+ MsgId2+ "|||\r");
                                    sb.Append("QAK||OK|^^^^^^^^|||\r");
                                    sb.Append("QPD|^^^^^^^^|||"+ strQueryID+"||\r");
                                    sb.Append("SPM||||SER||||||||||||||||||||||||\r");
                                    sb.Append("OBR||||||||||||||||||||||\r");
                                    sb.Append(strTestList);
                                    sb.Append("\u001c\r");
                                    strTestOrder = sb.ToString();
                                    strQueryID = "";

                                    try
                                    {
                                        string ipString = ConfigurationManager.AppSettings["IP"];
                                        int port = 55000;

                                        using (TcpClient client = new TcpClient(ipString, port))
                                        using (NetworkStream stream = client.GetStream())
                                        {


                                            /* string sendMsg = $"\vMSH|^~\\&|BiOLiS30i|||{DateTime.Now.ToString("yyyyMMdd")}||ACK^A08^ACK^^|{MsgId2}||2.5||||||ASCII|||\rMSA|AA|{MsgId2}||||\r\u001c\r";

                                             byte[] sendMsgBytes = Encoding.ASCII.GetBytes(sendMsg);
                                             stream.Write(sendMsgBytes, 0, sendMsgBytes.Length);*/

                                            byte[] testOrderBytes = Encoding.ASCII.GetBytes(strTestOrder);
                                            stream.Write(testOrderBytes, 0, testOrderBytes.Length);

                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        sw = File.AppendText(Application.StartupPath + "\\BIOSorder_exception.log");
                                        sw.WriteLine(DateTime.Now.ToString() + ex.ToString());
                                        sw.Close();

                                    }

                                    sw = File.AppendText(Application.StartupPath + "\\BIOS_OrderQuery_after.log");
                                    sw.WriteLine(DateTime.Now.ToString() + " : QueryData :" + strTestOrder);
                                    sw.Close();
                                    strTestOrder = "";

                                }
                                break;

                            }
                    }
                }
            }
            catch (Exception ex)
            {
                sw = File.AppendText(Application.StartupPath + "\\BIOS_SAVE_Log.log");
                sw.WriteLine(DateTime.Now.ToString() + " : QueryData : " + ex.Message);
                sw.Close();
            }
        }

        private int Asc(char p)
        {
            int num = p;
            return Convert.ToInt32(num.ToString());
        }
    }
}
