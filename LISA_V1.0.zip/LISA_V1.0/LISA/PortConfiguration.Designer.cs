﻿
namespace LISA
{
    partial class PortConfiguration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PortConfiguration));
            this.panel_portconfig = new System.Windows.Forms.Panel();
            this.radioButton_filebased = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbAnalyserName = new System.Windows.Forms.ComboBox();
            this.radioButtonNetwork = new System.Windows.Forms.RadioButton();
            this.radioButtonSerial = new System.Windows.Forms.RadioButton();
            this.groupBoxSerial = new System.Windows.Forms.GroupBox();
            this.checkBox_DTRRTS = new System.Windows.Forms.CheckBox();
            this.comboBox_handshake = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_stopbits = new System.Windows.Forms.ComboBox();
            this.comboBox_parity = new System.Windows.Forms.ComboBox();
            this.comboBox_databits = new System.Windows.Forms.ComboBox();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelport = new System.Windows.Forms.Label();
            this.comboBox_comport = new System.Windows.Forms.ComboBox();
            this.groupBoxNetwork = new System.Windows.Forms.GroupBox();
            this.radioButton_server = new System.Windows.Forms.RadioButton();
            this.radioButton_client = new System.Windows.Forms.RadioButton();
            this.textBox_analyzerip = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_portno = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_hostip = new System.Windows.Forms.TextBox();
            this.button_save = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.checkBox_isactive = new System.Windows.Forms.CheckBox();
            this.dataGridView_comportsettings = new System.Windows.Forms.DataGridView();
            this.button_delete = new System.Windows.Forms.Button();
            this.groupBox_filebased = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_FILEPATH = new System.Windows.Forms.TextBox();
            this.panel_portconfig.SuspendLayout();
            this.groupBoxSerial.SuspendLayout();
            this.groupBoxNetwork.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_comportsettings)).BeginInit();
            this.groupBox_filebased.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_portconfig
            // 
            this.panel_portconfig.BackColor = System.Drawing.Color.PowderBlue;
            this.panel_portconfig.Controls.Add(this.radioButton_filebased);
            this.panel_portconfig.Controls.Add(this.label9);
            this.panel_portconfig.Controls.Add(this.cmbAnalyserName);
            this.panel_portconfig.Controls.Add(this.radioButtonNetwork);
            this.panel_portconfig.Controls.Add(this.radioButtonSerial);
            this.panel_portconfig.Location = new System.Drawing.Point(0, 1);
            this.panel_portconfig.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel_portconfig.Name = "panel_portconfig";
            this.panel_portconfig.Size = new System.Drawing.Size(1062, 36);
            this.panel_portconfig.TabIndex = 0;
            // 
            // radioButton_filebased
            // 
            this.radioButton_filebased.AutoSize = true;
            this.radioButton_filebased.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.radioButton_filebased.ForeColor = System.Drawing.Color.DarkCyan;
            this.radioButton_filebased.Location = new System.Drawing.Point(854, -1);
            this.radioButton_filebased.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton_filebased.Name = "radioButton_filebased";
            this.radioButton_filebased.Size = new System.Drawing.Size(188, 19);
            this.radioButton_filebased.TabIndex = 4;
            this.radioButton_filebased.TabStop = true;
            this.radioButton_filebased.Text = "FILEBASED COMMUNICATION";
            this.radioButton_filebased.UseVisualStyleBackColor = true;
            this.radioButton_filebased.CheckedChanged += new System.EventHandler(this.radioButton_filebased_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(44, 11);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 15);
            this.label9.TabIndex = 3;
            this.label9.Text = "ANALYZER NAME";
            // 
            // cmbAnalyserName
            // 
            this.cmbAnalyserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnalyserName.FormattingEnabled = true;
            this.cmbAnalyserName.Location = new System.Drawing.Point(202, 5);
            this.cmbAnalyserName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbAnalyserName.Name = "cmbAnalyserName";
            this.cmbAnalyserName.Size = new System.Drawing.Size(196, 23);
            this.cmbAnalyserName.TabIndex = 2;
            // 
            // radioButtonNetwork
            // 
            this.radioButtonNetwork.AutoSize = true;
            this.radioButtonNetwork.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.radioButtonNetwork.ForeColor = System.Drawing.Color.DarkCyan;
            this.radioButtonNetwork.Location = new System.Drawing.Point(598, 17);
            this.radioButtonNetwork.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonNetwork.Name = "radioButtonNetwork";
            this.radioButtonNetwork.Size = new System.Drawing.Size(233, 19);
            this.radioButtonNetwork.TabIndex = 1;
            this.radioButtonNetwork.TabStop = true;
            this.radioButtonNetwork.Text = "NETWORK (TCP/IP) COMMUNICATION";
            this.radioButtonNetwork.UseVisualStyleBackColor = true;
            this.radioButtonNetwork.CheckedChanged += new System.EventHandler(this.radioButtonNetwork_CheckedChanged);
            // 
            // radioButtonSerial
            // 
            this.radioButtonSerial.AutoSize = true;
            this.radioButtonSerial.Checked = true;
            this.radioButtonSerial.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.radioButtonSerial.ForeColor = System.Drawing.Color.DarkCyan;
            this.radioButtonSerial.Location = new System.Drawing.Point(598, -2);
            this.radioButtonSerial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonSerial.Name = "radioButtonSerial";
            this.radioButtonSerial.Size = new System.Drawing.Size(167, 19);
            this.radioButtonSerial.TabIndex = 0;
            this.radioButtonSerial.TabStop = true;
            this.radioButtonSerial.Text = "SERIAL COMMUNICATION";
            this.radioButtonSerial.UseVisualStyleBackColor = true;
            this.radioButtonSerial.CheckedChanged += new System.EventHandler(this.radioButtonSerial_CheckedChanged);
            // 
            // groupBoxSerial
            // 
            this.groupBoxSerial.BackColor = System.Drawing.Color.MintCream;
            this.groupBoxSerial.Controls.Add(this.checkBox_DTRRTS);
            this.groupBoxSerial.Controls.Add(this.comboBox_handshake);
            this.groupBoxSerial.Controls.Add(this.label5);
            this.groupBoxSerial.Controls.Add(this.comboBox_stopbits);
            this.groupBoxSerial.Controls.Add(this.comboBox_parity);
            this.groupBoxSerial.Controls.Add(this.comboBox_databits);
            this.groupBoxSerial.Controls.Add(this.comboBoxBaudRate);
            this.groupBoxSerial.Controls.Add(this.label4);
            this.groupBoxSerial.Controls.Add(this.label3);
            this.groupBoxSerial.Controls.Add(this.label2);
            this.groupBoxSerial.Controls.Add(this.label1);
            this.groupBoxSerial.Controls.Add(this.labelport);
            this.groupBoxSerial.Controls.Add(this.comboBox_comport);
            this.groupBoxSerial.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBoxSerial.Location = new System.Drawing.Point(1, 41);
            this.groupBoxSerial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxSerial.Name = "groupBoxSerial";
            this.groupBoxSerial.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxSerial.Size = new System.Drawing.Size(461, 205);
            this.groupBoxSerial.TabIndex = 1;
            this.groupBoxSerial.TabStop = false;
            this.groupBoxSerial.Text = "SERIAL";
            // 
            // checkBox_DTRRTS
            // 
            this.checkBox_DTRRTS.AutoSize = true;
            this.checkBox_DTRRTS.Location = new System.Drawing.Point(50, 175);
            this.checkBox_DTRRTS.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBox_DTRRTS.Name = "checkBox_DTRRTS";
            this.checkBox_DTRRTS.Size = new System.Drawing.Size(75, 19);
            this.checkBox_DTRRTS.TabIndex = 16;
            this.checkBox_DTRRTS.Text = "DTR/RTS";
            this.checkBox_DTRRTS.UseVisualStyleBackColor = true;
            // 
            // comboBox_handshake
            // 
            this.comboBox_handshake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_handshake.FormattingEnabled = true;
            this.comboBox_handshake.Items.AddRange(new object[] {
            "None",
            "XOnXOff",
            "RequestToSend",
            "RequestToSendXOnXOff"});
            this.comboBox_handshake.Location = new System.Drawing.Point(267, 136);
            this.comboBox_handshake.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_handshake.Name = "comboBox_handshake";
            this.comboBox_handshake.Size = new System.Drawing.Size(159, 23);
            this.comboBox_handshake.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(265, 120);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "HANDSHAKE";
            // 
            // comboBox_stopbits
            // 
            this.comboBox_stopbits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_stopbits.FormattingEnabled = true;
            this.comboBox_stopbits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.comboBox_stopbits.Location = new System.Drawing.Point(267, 86);
            this.comboBox_stopbits.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_stopbits.Name = "comboBox_stopbits";
            this.comboBox_stopbits.Size = new System.Drawing.Size(159, 23);
            this.comboBox_stopbits.TabIndex = 13;
            // 
            // comboBox_parity
            // 
            this.comboBox_parity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_parity.FormattingEnabled = true;
            this.comboBox_parity.Items.AddRange(new object[] {
            "None",
            "Even",
            "Odd",
            "Mark",
            "Space"});
            this.comboBox_parity.Location = new System.Drawing.Point(267, 39);
            this.comboBox_parity.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_parity.Name = "comboBox_parity";
            this.comboBox_parity.Size = new System.Drawing.Size(159, 23);
            this.comboBox_parity.TabIndex = 12;
            // 
            // comboBox_databits
            // 
            this.comboBox_databits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_databits.FormattingEnabled = true;
            this.comboBox_databits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.comboBox_databits.Location = new System.Drawing.Point(48, 136);
            this.comboBox_databits.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_databits.Name = "comboBox_databits";
            this.comboBox_databits.Size = new System.Drawing.Size(159, 23);
            this.comboBox_databits.TabIndex = 11;
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "128000"});
            this.comboBoxBaudRate.Location = new System.Drawing.Point(47, 86);
            this.comboBoxBaudRate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.Size = new System.Drawing.Size(159, 23);
            this.comboBoxBaudRate.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(262, 71);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "STOPBITS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(265, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "PARITY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 120);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "DATABITS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "BAUDRATE";
            // 
            // labelport
            // 
            this.labelport.AutoSize = true;
            this.labelport.Location = new System.Drawing.Point(43, 24);
            this.labelport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelport.Name = "labelport";
            this.labelport.Size = new System.Drawing.Size(66, 15);
            this.labelport.TabIndex = 1;
            this.labelport.Text = "COMPORT";
            // 
            // comboBox_comport
            // 
            this.comboBox_comport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_comport.FormattingEnabled = true;
            this.comboBox_comport.Location = new System.Drawing.Point(46, 39);
            this.comboBox_comport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_comport.Name = "comboBox_comport";
            this.comboBox_comport.Size = new System.Drawing.Size(159, 23);
            this.comboBox_comport.TabIndex = 0;
            // 
            // groupBoxNetwork
            // 
            this.groupBoxNetwork.BackColor = System.Drawing.Color.Thistle;
            this.groupBoxNetwork.Controls.Add(this.radioButton_server);
            this.groupBoxNetwork.Controls.Add(this.radioButton_client);
            this.groupBoxNetwork.Controls.Add(this.textBox_analyzerip);
            this.groupBoxNetwork.Controls.Add(this.label8);
            this.groupBoxNetwork.Controls.Add(this.textBox_portno);
            this.groupBoxNetwork.Controls.Add(this.label7);
            this.groupBoxNetwork.Controls.Add(this.label6);
            this.groupBoxNetwork.Controls.Add(this.textBox_hostip);
            this.groupBoxNetwork.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBoxNetwork.Location = new System.Drawing.Point(475, 42);
            this.groupBoxNetwork.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxNetwork.Name = "groupBoxNetwork";
            this.groupBoxNetwork.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxNetwork.Size = new System.Drawing.Size(298, 204);
            this.groupBoxNetwork.TabIndex = 2;
            this.groupBoxNetwork.TabStop = false;
            this.groupBoxNetwork.Text = "NETWORK (TCP/IP)";
            // 
            // radioButton_server
            // 
            this.radioButton_server.AutoSize = true;
            this.radioButton_server.Checked = true;
            this.radioButton_server.Location = new System.Drawing.Point(43, 172);
            this.radioButton_server.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton_server.Name = "radioButton_server";
            this.radioButton_server.Size = new System.Drawing.Size(71, 19);
            this.radioButton_server.TabIndex = 7;
            this.radioButton_server.TabStop = true;
            this.radioButton_server.Text = "SERVER";
            this.radioButton_server.UseVisualStyleBackColor = true;
            // 
            // radioButton_client
            // 
            this.radioButton_client.AutoSize = true;
            this.radioButton_client.Location = new System.Drawing.Point(187, 172);
            this.radioButton_client.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButton_client.Name = "radioButton_client";
            this.radioButton_client.Size = new System.Drawing.Size(65, 19);
            this.radioButton_client.TabIndex = 6;
            this.radioButton_client.Text = "CLIENT";
            this.radioButton_client.UseVisualStyleBackColor = true;
            // 
            // textBox_analyzerip
            // 
            this.textBox_analyzerip.Location = new System.Drawing.Point(42, 135);
            this.textBox_analyzerip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox_analyzerip.Name = "textBox_analyzerip";
            this.textBox_analyzerip.Size = new System.Drawing.Size(215, 21);
            this.textBox_analyzerip.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 119);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "ANALYZER ADDRESS";
            // 
            // textBox_portno
            // 
            this.textBox_portno.Location = new System.Drawing.Point(43, 85);
            this.textBox_portno.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox_portno.Name = "textBox_portno";
            this.textBox_portno.Size = new System.Drawing.Size(111, 21);
            this.textBox_portno.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 66);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "PORT NO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 20);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "HOST ADDRESS";
            // 
            // textBox_hostip
            // 
            this.textBox_hostip.Location = new System.Drawing.Point(43, 36);
            this.textBox_hostip.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox_hostip.Name = "textBox_hostip";
            this.textBox_hostip.Size = new System.Drawing.Size(215, 21);
            this.textBox_hostip.TabIndex = 0;
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.AliceBlue;
            this.button_save.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_save.Location = new System.Drawing.Point(457, 247);
            this.button_save.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(121, 26);
            this.button_save.TabIndex = 3;
            this.button_save.Text = "SAVE";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.MintCream;
            this.button_clear.Location = new System.Drawing.Point(636, 247);
            this.button_clear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(121, 26);
            this.button_clear.TabIndex = 4;
            this.button_clear.Text = "CLEAR";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // checkBox_isactive
            // 
            this.checkBox_isactive.AutoSize = true;
            this.checkBox_isactive.Checked = true;
            this.checkBox_isactive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_isactive.Location = new System.Drawing.Point(202, 250);
            this.checkBox_isactive.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBox_isactive.Name = "checkBox_isactive";
            this.checkBox_isactive.Size = new System.Drawing.Size(70, 19);
            this.checkBox_isactive.TabIndex = 18;
            this.checkBox_isactive.Text = "STATUS";
            this.checkBox_isactive.UseVisualStyleBackColor = true;
            // 
            // dataGridView_comportsettings
            // 
            this.dataGridView_comportsettings.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_comportsettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_comportsettings.Location = new System.Drawing.Point(0, 276);
            this.dataGridView_comportsettings.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView_comportsettings.Name = "dataGridView_comportsettings";
            this.dataGridView_comportsettings.RowTemplate.Height = 25;
            this.dataGridView_comportsettings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_comportsettings.Size = new System.Drawing.Size(1062, 258);
            this.dataGridView_comportsettings.TabIndex = 19;
            this.dataGridView_comportsettings.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_comportsettings_CellDoubleClick);
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.MintCream;
            this.button_delete.Location = new System.Drawing.Point(820, 247);
            this.button_delete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(121, 26);
            this.button_delete.TabIndex = 20;
            this.button_delete.Text = "DELETE";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // groupBox_filebased
            // 
            this.groupBox_filebased.BackColor = System.Drawing.Color.Pink;
            this.groupBox_filebased.Controls.Add(this.label12);
            this.groupBox_filebased.Controls.Add(this.textBox_FILEPATH);
            this.groupBox_filebased.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBox_filebased.Location = new System.Drawing.Point(786, 44);
            this.groupBox_filebased.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox_filebased.Name = "groupBox_filebased";
            this.groupBox_filebased.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox_filebased.Size = new System.Drawing.Size(265, 204);
            this.groupBox_filebased.TabIndex = 21;
            this.groupBox_filebased.TabStop = false;
            this.groupBox_filebased.Text = "FILEBASED";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 45);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "FILE PATH";
            // 
            // textBox_FILEPATH
            // 
            this.textBox_FILEPATH.Location = new System.Drawing.Point(20, 64);
            this.textBox_FILEPATH.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox_FILEPATH.Name = "textBox_FILEPATH";
            this.textBox_FILEPATH.Size = new System.Drawing.Size(215, 21);
            this.textBox_FILEPATH.TabIndex = 0;
            // 
            // PortConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1063, 537);
            this.Controls.Add(this.groupBox_filebased);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.dataGridView_comportsettings);
            this.Controls.Add(this.checkBox_isactive);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.groupBoxNetwork);
            this.Controls.Add(this.groupBoxSerial);
            this.Controls.Add(this.panel_portconfig);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PortConfiguration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comm. Port Configuration";
            this.Load += new System.EventHandler(this.PortConfiguration_Load);
            this.panel_portconfig.ResumeLayout(false);
            this.panel_portconfig.PerformLayout();
            this.groupBoxSerial.ResumeLayout(false);
            this.groupBoxSerial.PerformLayout();
            this.groupBoxNetwork.ResumeLayout(false);
            this.groupBoxNetwork.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_comportsettings)).EndInit();
            this.groupBox_filebased.ResumeLayout(false);
            this.groupBox_filebased.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_portconfig;
        private System.Windows.Forms.RadioButton radioButtonNetwork;
        private System.Windows.Forms.RadioButton radioButtonSerial;
        private System.Windows.Forms.GroupBox groupBoxSerial;
        private System.Windows.Forms.GroupBox groupBoxNetwork;
        private System.Windows.Forms.ComboBox comboBox_comport;
        private System.Windows.Forms.Label labelport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxBaudRate;
        private System.Windows.Forms.ComboBox comboBox_databits;
        private System.Windows.Forms.ComboBox comboBox_stopbits;
        private System.Windows.Forms.ComboBox comboBox_parity;
        private System.Windows.Forms.ComboBox comboBox_handshake;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBox_DTRRTS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_hostip;
        private System.Windows.Forms.TextBox textBox_portno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_analyzerip;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radioButton_server;
        private System.Windows.Forms.RadioButton radioButton_client;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbAnalyserName;
        private System.Windows.Forms.CheckBox checkBox_isactive;
        private System.Windows.Forms.DataGridView dataGridView_comportsettings;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.RadioButton radioButton_filebased;
        private System.Windows.Forms.GroupBox groupBox_filebased;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_FILEPATH;
    }
}