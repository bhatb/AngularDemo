﻿using System.IO.Ports;
using System.Net.Sockets;

namespace LISA
{
    public interface LISAINTERFACE_SERIAL
    {
        void ParseData_Serial(string bytes, SerialPort sPort);

    }

    public interface LISAINTERFACE_NETWORK
    {
        void ParseDataTCP_Server(string strReceived, NetworkStream Client);
    }

    public interface LISAINTERFACE_NETWORK_CLIENT
    {
        void ParseDataTCP_Client(string strReceived, Socket Client);
    }

    public interface LISAINTERFACE_FILEBASE
    {
        void ParseDataFileBase(string strReceived, string FilePath);
    }
}
