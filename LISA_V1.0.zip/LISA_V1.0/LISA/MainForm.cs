﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.IO;
using System.IO.Ports;

namespace LISA
{
    public partial class MainForm : Form
    {
        private CONNECTION objCONNECTION;
        private StreamWriter sw;
        public string mac_address;

        public MainForm()
        {
            InitializeComponent();

            mac_address = check_macaddress();
            //if (mac_address != "601895337554")
            if (1 == 2)
            {
                MessageBox.Show("NOT A VALID USER", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                System.Environment.Exit(1);
            }
        }

        private void run_analyzers_parallel()
        {
            try
            {
                string[] ports = SerialPort.GetPortNames();
                DataTable dt = new DataTable();
                objCONNECTION = new CONNECTION();
                dt = objCONNECTION.GetDataTable("select (select mana_machinename from lb_mana_machinename where mana_machinenameid=cs_analyzerid)analyzer,lcc.* from lb_cs_comportsetting lcc where cs_macaddress='" + mac_address+ "' and cs_isactive ='Y' order by cs_comportid");
                
                if (dt != null && dt.Rows.Count > 0)
                {
                    AnalyzerDetails.Controls.Clear();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        bool chk_comport_present = false;
                        if (dt.Rows[i]["cs_protocol"].ToString() == "SERIAL")
                        {
                            
                            foreach (string comport in ports)
                            {
                                if (dt.Rows[i]["cs_portnumber"].ToString() == comport)
                                {
                                    chk_comport_present = true;
                                }
                            }
                        }
                        else
                        {
                            chk_comport_present = true;
                        }

                        if (chk_comport_present == true)
                        {
                            UserControlAnalyzer ucl = new UserControlAnalyzer(dt.Rows[i]);
                            AnalyzerDetails.Controls.Add(ucl);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No Port Configuration Available", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch(Exception ex)
            {
                sw = File.AppendText(Application.StartupPath + "\\run_analyzer_parallel.log");
                sw.WriteLine(DateTime.Now.ToString() + ex.Message);
                sw.Close();
            }
        }

        private string check_macaddress()
        {
            string text = string.Empty;
            NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface networkInterface in allNetworkInterfaces)
            {
                if (networkInterface.OperationalStatus == OperationalStatus.Up)
                {
                    text += networkInterface.GetPhysicalAddress().ToString();
                    break;
                }
            }
            return text;
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("Do You Want to Close LISA", "Close!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            // {
            //    Environment.Exit(Environment.ExitCode);
            // }

            try
            {
                Form_Verification objverification = new Form_Verification();
                objverification.Text = "Exit Authorization";
                objverification.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Form_Main_Load(object sender, EventArgs e)
        {
            try
            {
                run_analyzers_parallel();
            }
            catch (Exception ex)
            {
                run_analyzers_parallel();
            }
        }

        private void button_minimize_Click(object sender, EventArgs e)
        {
            base.WindowState = FormWindowState.Minimized;
            Hide();
            notifyIconLISA.Visible = true;
            notifyIconLISA.ShowBalloonTip(1000, "LISA", " Minimized", ToolTipIcon.Info);
        }

        private void lISASETUPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void ANALYZERCONFIGURATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //try
            //{
            //     PortConfiguration objportConfiguration = new PortConfiguration();
            //    objportConfiguration.Show();
            //}
            //catch(Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}

            try
            {
                Form_Verification objverification = new Form_Verification();
                objverification.Text = "Configuration Authorization";
                objverification.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        
        private void notifyIconLISA_Click(object sender, EventArgs e)
        {

            Show();
            base.WindowState = FormWindowState.Normal;
            notifyIconLISA.Visible = false;
        }

        private void portConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("LISA", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_reload_Click(object sender, EventArgs e)
        {
            try
            {

                System.Diagnostics.Process.Start(Application.StartupPath + "\\LISA.exe");
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }
            catch (Exception ex)
            {

            }
        }
    }
}
