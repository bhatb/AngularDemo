﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LISA
{
    public partial class Form_Verification : Form
    {
        public Form_Verification()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "abc@321")
            {
                if (this.Text == "Login")
                {
                    try
                    {
                        this.Hide();
                        MainForm objmainform = new MainForm();
                        objmainform.Show();
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else if (this.Text == "Configuration Authorization")
                {
                    try
                    {
                        PortConfiguration objportconfiguration = new PortConfiguration();
                        objportconfiguration.Show();
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }

                }
                else if (this.Text == "Exit Authorization")
                {
                    if (MessageBox.Show("Do You Want to Close LISA", "Close!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        Environment.Exit(Environment.ExitCode);
                    }
                }


            }
            else
            {
                MessageBox.Show("NOT A VALID USER", "LISA V1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //System.Environment.Exit(1);
            }
            
        }

    }
}
